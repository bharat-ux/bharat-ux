DEVELOPER TOOLS FOR DADA MAIL

These are some files that come in handy when developing for Dada Mail! Yeah!
